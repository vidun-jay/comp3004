/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_E
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *E)
    {
        if (E->objectName().isEmpty())
            E->setObjectName("E");
        E->resize(713, 645);
        centralwidget = new QWidget(E);
        centralwidget->setObjectName("centralwidget");
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(240, 20, 101, 101));
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(370, 20, 101, 101));
        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setGeometry(QRect(370, 140, 101, 101));
        pushButton_4 = new QPushButton(centralwidget);
        pushButton_4->setObjectName("pushButton_4");
        pushButton_4->setGeometry(QRect(240, 140, 101, 101));
        pushButton_5 = new QPushButton(centralwidget);
        pushButton_5->setObjectName("pushButton_5");
        pushButton_5->setGeometry(QRect(370, 260, 101, 101));
        pushButton_6 = new QPushButton(centralwidget);
        pushButton_6->setObjectName("pushButton_6");
        pushButton_6->setGeometry(QRect(240, 260, 101, 101));
        pushButton_7 = new QPushButton(centralwidget);
        pushButton_7->setObjectName("pushButton_7");
        pushButton_7->setGeometry(QRect(170, 410, 101, 101));
        pushButton_9 = new QPushButton(centralwidget);
        pushButton_9->setObjectName("pushButton_9");
        pushButton_9->setGeometry(QRect(300, 410, 101, 101));
        pushButton_10 = new QPushButton(centralwidget);
        pushButton_10->setObjectName("pushButton_10");
        pushButton_10->setGeometry(QRect(430, 410, 101, 101));
        E->setCentralWidget(centralwidget);
        menubar = new QMenuBar(E);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 713, 24));
        E->setMenuBar(menubar);
        statusbar = new QStatusBar(E);
        statusbar->setObjectName("statusbar");
        E->setStatusBar(statusbar);

        retranslateUi(E);

        QMetaObject::connectSlotsByName(E);
    } // setupUi

    void retranslateUi(QMainWindow *E)
    {
        E->setWindowTitle(QCoreApplication::translate("E", "MainWindow", nullptr));
        pushButton->setText(QCoreApplication::translate("E", "5", nullptr));
        pushButton_2->setText(QCoreApplication::translate("E", "6", nullptr));
        pushButton_3->setText(QCoreApplication::translate("E", "4", nullptr));
        pushButton_4->setText(QCoreApplication::translate("E", "3", nullptr));
        pushButton_5->setText(QCoreApplication::translate("E", "2", nullptr));
        pushButton_6->setText(QCoreApplication::translate("E", "1", nullptr));
        pushButton_7->setText(QCoreApplication::translate("E", "Open", nullptr));
        pushButton_9->setText(QCoreApplication::translate("E", "Close", nullptr));
        pushButton_10->setText(QCoreApplication::translate("E", "Close", nullptr));
    } // retranslateUi

};

namespace Ui {
    class E: public Ui_E {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
